let Page = require('./page');

class LogInPage extends Page {
    constructor(){
        super();
    }

    // Log-in Page Message
    get logInMessage()          { return browser.element("//*[@id='logInError']"); }

    // Breadcrumbs links
    get email()                 { return browser.element("//*[@id='email']"); }
    get password()              { return browser.element("//*[@id='password']"); }

    // Log-in button
    get login()                 { return browser.element("//*[@id='logInButton']"); }

    clickOn(element){
        this[element].waitForExist();
        this[element].waitForVisible();
        this[element].isEnabled();
        this[element].click();
    }
    
    setFieldValue(field,value){
        this[field].waitForExist();
        this[field].waitForVisible();
        this[field].setValue(value);
    }

    checkLabelValue(label,value){
        this[label].waitForExist();
        this[label].waitForVisible();
        var message = this[label].getText();
        expect( ( message === value ) , "Message different that expected!" ).to.be.true;
    }
}
module.exports = new LogInPage();