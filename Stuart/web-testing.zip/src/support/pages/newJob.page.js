let Page = require('./page');

class newJobPage extends Page {
    constructor(){
        super();
    }

    // Divs 
    get newJob()                { return browser.element("//*[@id='newJobPage']"); }
    get activeJobs()            { return browser.element("//*[@id='activeJobsPage']"); }

    // Pick-Up fields
    get pickUpAddress()         { return browser.element("//*[@id='pickUpCard-0-fields-field-address']"); }
    get pickUpFirstname()       { return browser.element("//*[@id='pickUpCard-0-fields-field-firstname']"); }
    get pickUpLastname()        { return browser.element("//*[@id='pickUpCard-0-fields-field-lastname']"); }
    get pickUpCompany()         { return browser.element("//*[@id='pickUpCard-0-fields-field-company']"); }
    get pickUpPhone()           { return browser.element("//*[@id='pickUpCard-0-fields-field-phone']"); }
    get pickUpEmail()           { return browser.element("//*[@id='pickUpCard-0-fields-field-email']"); }
    get pickUpComment()         { return browser.element("//*[@id='pickUpCard-0-fields-field-comment']"); }
    get pickUpAutoComplete()    { return browser.element("#autocompleteItems > div:nth-child(1)"); }

    // Drop-Off
    get dropOffAddress()         { return browser.element("//*[@id='dropOffCard-0-fields-field-address']"); }
    get dropOffFirstname()       { return browser.element("//*[@id='dropOffCard-0-fields-field-firstname']"); }
    get dropOffLastname()        { return browser.element("//*[@id='dropOffCard-0-fields-field-lastname']"); }
    get dropOffCompany()         { return browser.element("//*[@id='dropOffCard-0-fields-field-company']"); }
    get dropOffPhone()           { return browser.element("//*[@id='dropOffCard-0-fields-field-phone']"); }
    get dropOffEmail()           { return browser.element("//*[@id='dropOffCard-0-fields-field-email']"); }
    get dropOffComment()         { return browser.element("//*[@id='dropOffCard-0-fields-field-comment']"); }
    get dropOffAutoComplete()    { return browser.element("#autocompleteItems > div:nth-child(1)"); }

    // Buttons
    get request()                { return browser.element("//*[@id='requestButton']"); }
    get bike()                   { return browser.element("//*[@name='transport-bike']"); }

    clickOn(element){
        browser.pause(1000);
        this[element].waitForExist();
        this[element].waitForVisible();
        this[element].isEnabled();
        this[element].click();
        browser.pause(2000);
    }
    
    setFieldValue(field,value){
        this[field].waitForExist();
        this[field].waitForVisible();
        this[field].setValue(value);
    }

    checkElementExist(element){
        this[element].waitForExist();
        this[element].waitForVisible();
        expect( ( this[element].isExisting() ) , this[element].name + " doesn't exists!" ).to.be.true;
    }

    checkLabelValue(label,value){
        this[label].waitForExist();
        this[label].waitForVisible();
        var message = this[label].getText();
        expect( ( message === value ) , "Message different that expected!" ).to.be.true;
    }
}
module.exports = new newJobPage();