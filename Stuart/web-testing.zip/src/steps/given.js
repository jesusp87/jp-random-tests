import openWebsite              from '../support/action/openWebsite';
import loginPage                from '../support/pages/login.page';

const { Given } = require('cucumber');

Given(/^I open the (url|site) "([^"]*)?"$/,
    openWebsite
);

Given(/^I set "([^"]*)?" on "([^"]*)?" login-field/, function( value, field ){
    loginPage.setFieldValue( field, value );
});