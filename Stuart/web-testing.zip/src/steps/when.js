import loginPage from '../support/pages/login.page';
import newJobPage from '../support/pages/newJob.page';

const { When } = require('cucumber');

When(/^I click on "([^"]*)?" (button|link)$/, function( optionToSel, opt ){
    loginPage.clickOn( optionToSel );
});

When(/^I click on "([^"]*)?" button on loginPage$/, function( optionToSel ){
    loginPage.clickOn( optionToSel );
});

When(/^I set "([^"]*)?" on "([^"]*)?" field on delivery-page/, function( value, field ){
    newJobPage.setFieldValue( field, value );
});

When(/^I click on "([^"]*)?" (autocomplete|button|element) on delivery-page/, function( aux, opt ){
    newJobPage.clickOn( aux );
});
