import loginPage        from '../support/pages/login.page';
import newJobPage       from '../support/pages/newJob.page';

const { Then } = require('cucumber');

Then(/^check that I am in the "([^"]*)?" page/, function( pageId ){
    newJobPage.checkElementExist( pageId );
});

Then(/^check that "([^"]*)?" says "([^"]*)?"/, function( label, value ){
    loginPage.checkLabelValue( label, value );
});

Then(/^check that "([^"]*)?" value is "([^"]*)?"/, function( label, value ){
    newJobPage.checkLabelValue( label, value );
});
