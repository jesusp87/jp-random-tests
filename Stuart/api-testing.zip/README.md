## Requeriments ##
 - Maven > 3.5.0 https://maven.apache.org/download.cgi
 - Java > 1.8.0

## Project Structure ##

| PATH        | PURPOSE           | 
| :------------- |:-------------| 
| suites | TestNG files |
| src / main / java / resources / conf | Configuration file and other file properties to help the testing |
| src / main / java / com / stuart / api / testing / action | Classes to manage actions or steps to do a test case |
| src / main / java / com / stuart / api / testing / data | Classes and enums to manage actions and responses |
| src / main / java / com / stuart / api / testing / scenario | Scenarios - test cases |
| src / main / java / com / stuart / api / testing / tool | Common classes to perform general changes or methods | 


## How to execute tests? ##
```sh
mvn clean install -Dsuite=suite_path/suite_name
```
**Example:** 

mvn clean install -Dsuite=jobs/validations

*The tests in jobs/validations.xml will be executed against the Sandbox environment*

   