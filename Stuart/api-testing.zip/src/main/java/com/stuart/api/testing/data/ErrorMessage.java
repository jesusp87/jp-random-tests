package com.stuart.api.testing.data;

import com.google.gson.Gson;

/**
 * APIs ErrorMessages
 * @author Jesus Pereira
 */
public class ErrorMessage {

    private String error;
    private String message;
    private transient String data;

    public ErrorMessage() {
        this.error = "";
        this.message = "";
        this.data = "";
    }
    
    /**
     * @return the error
     */
    public String getError() {
        return error;
    }

    /**
     * @param error the error to set
     */
    public void setError(String error) {
        this.error = error;
    }

    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }

    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * @return the data
     */
    public String getData() {
        return data;
    }

    /**
     * @param data the data to set
     */
    public void setData(String data) {
        this.data = data;
    }
    
    public ErrorMessage fromJSONString(String json) {
        Gson gson = new Gson();
        ErrorMessage aux = gson.fromJson(json, ErrorMessage.class);
        return aux;
    }
}
