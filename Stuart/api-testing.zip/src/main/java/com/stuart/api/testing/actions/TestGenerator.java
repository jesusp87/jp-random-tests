package com.stuart.api.testing.actions;

import com.stuart.api.testing.data.ActionEnum;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Class to generate tests
 * @author Jesus Pereira
 */
public class TestGenerator {

    // Data Properties file
    protected Properties endpointsProperties = new Properties();
    private String action;
    private String body;
    private String endpoint;
    private String method;
    
    public TestGenerator(String action) {
        try {
            this.action = action;
            this.endpointsProperties.loadFromXML(new FileInputStream("conf/endpoints-properties.xml"));
        } catch (IOException ex) {
            Logger.getLogger(API.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void generateBody(String param){
        String bodyAux = "{}";
        if(this.action != null ){
            try{
                ActionEnum actionEnum = ActionEnum.byValue(this.action);
                switch(actionEnum){
                    case JOBS_VALIDATE:
                        bodyAux = new String(Files.readAllBytes(Paths.get("data_tests/"+param+".json")));
                        break;
                }
            }   catch (IOException ex) {
                Logger.getLogger(TestGenerator.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        SetBody(bodyAux);
    }
    
    public void generateEndPoint(String params){
        String path = "";
        if( params != null && (!params.equals("")) ){
            ActionEnum actionEnum = ActionEnum.byValue(this.action);
            switch(actionEnum){
                case ADDRESS_VALIDATE:
                    path = "?" + params;
                    break;
            }
        }
        setMethod(   endpointsProperties.getProperty( this.action+".method" ) );
        setEndpoint( endpointsProperties.getProperty( this.action ) + path );
    }
    
    /**
     * @return the body
     */
    public String getBody() {
        return body;
    }
    
    /**
     * @param body the body to set
     */
    public void SetBody(String body){
        this.body = body;
    }

    /**
     * @return the endpoint
     */
    public String getEndpoint() {
        return endpoint;
    }

    /**
     * @param endpoint the endpoint to set
     */
    public void setEndpoint(String endpoint) {
        this.endpoint = endpoint;
    }

    /**
     * @return the method
     */
    public String getMethod() {
        return method;
    }

    /**
     * @param method the method to set
     */
    public void setMethod(String method) {
        this.method = method;
    }
}
