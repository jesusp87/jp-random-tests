package com.stuart.api.testing.data;

/**
 * APIs actions
 * @author Jesus Pereira
 **/
public enum ActionEnum {
    JOBS_VALIDATE ("jobs.validate"),
    ADDRESS_VALIDATE ("addresses.validate");
    
    private final String method;       

    private ActionEnum(String s) {
        method = s;
    }

    public boolean equalsTo(String otherAction) {
        return method.equals(otherAction);
    }

    public String toString() {
       return this.method;
    }
    
    public static ActionEnum byValue(String val){
        for(ActionEnum en:values()){
            if(en.method.equals(val)){
                return en;
            }
        }
    return null;
    }
}