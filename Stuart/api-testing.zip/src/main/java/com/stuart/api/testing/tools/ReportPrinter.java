package com.stuart.api.testing.tools;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.jayway.restassured.response.Response;
import java.util.regex.Pattern;
import org.testng.Reporter;

/**
 * Tool to prettyprint messages
 * @author Jesus Pereira
 */
public class ReportPrinter {
    
    private static String successColor = "#44aa44";
    private static String failureColor = "#ff4444";
    
    public void printSegment(String segment) {
        Reporter.log("</br><hr> <div class=\"parameter\"> <b>" + segment + "</b> </div>" );
    }
    
    public void printColorMessage(boolean condition, String message){
        String color = (condition) ? this.successColor : this.failureColor;
        Reporter.log("<a style=\"text-decoration: none; color: " + color + "\"> <b> " + message + " </b> </a> ");
    }
    
    public void printCodesComparison(int expectedCode, int respCode, boolean boolCodes){
        Reporter.log("<b>Status Code: </b> "); 
        Reporter.log("<br> Expected: " + expectedCode );
        printColorMessage(boolCodes, ", Received: " + respCode + "</br>");
    }
    
    public void printMessageComparion(String expectedMsg, String respMsg, boolean boolMsg) {
        Reporter.log("</br><b>Message: </b></br>");
        if(boolMsg){
            printColorMessage(boolMsg, "Found within the answer.");
        }else{
            Reporter.log( expectedMsg );
            printColorMessage(boolMsg, " -> Not found!");
        }
        Reporter.log("</br>");
    }
    
    public void printExecutionTimes(long generationTime, long serverTime, long validationTime ){
        printSegment("EXECUTION TIMES:");
        Reporter.log("<table> <tbody>");
        Reporter.log("<tr><td style=\"font-size: 1em;\"> Request Generation </td> "
                       + "<td style=\"font-size: 1em; padding-left: 1em;\"> [</td> "
                       + "<td style=\"font-size: 1em; padding-left: 2em;\" align=\"right\"><b>" + generationTime + " ms </b> ] </td></tr>" );
        Reporter.log("<tr><td style=\"font-size: 1em;\"> Server Response </td>    "
                       + "<td style=\"font-size: 1em; padding-left: 1em;\"> [</td> "
                       + "<td style=\"font-size: 1em; padding-left: 2em;\" align=\"right\"><b>" + serverTime +    " ms </b> ] </td></tr>" );
        Reporter.log("<tr><td style=\"font-size: 1em;\"> Validations </td>        "
                       + "<td style=\"font-size: 1em; padding-left: 1em;\"> [</td> "
                       + "<td style=\"font-size: 1em; padding-left: 2em;\" align=\"right\"><b>" + validationTime + " ms </b> ] </td></tr>" );
        Reporter.log("</tbody><table>");
        Reporter.log("</br>");
    }
    
    /**
     * Print Information about Request
     * @param method
     */
    public void printHeadersInformation(String method, String auth, String endpoint) {
        printSegment("HEADERS:");
        Reporter.log("<b>Environment:</b> " + "Stuart-Sandbox" + "</br>");
        Reporter.log("<b>Authorization:</b> " + auth + "</br>");
        Reporter.log("<b>Endpoint:</b> " + method + " - " + endpoint + "</br>");
    }
    
    /**
     * Print Information about Request and Response
     * @param requestBody
     * @param resp
     */
    public void printInformation(String requestBody, Response resp) {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        JsonParser jp = new JsonParser();
        printSegment("REQUEST:" );
        JsonElement je = jp.parse( requestBody );
        String prettyJsonString = gson.toJson(je);
        Reporter.log( "<pre id=\"json\">" +prettyJsonString + "</pre>" );
        printSegment("RESPONSE:" );
        Reporter.log("<b> Status Code: </b>"+ resp.statusCode() + "<br>" );
        Pattern pattern = Pattern.compile("\\{.*\\:.*\\}");
        if( pattern.matcher( resp.getBody().asString() ).matches() ){
            je = jp.parse( resp.getBody().prettyPrint() );
            prettyJsonString = gson.toJson(je);
        }else{
            prettyJsonString = resp.getBody().prettyPrint();
        }    
        Reporter.log( "<pre id=\"json\">" +prettyJsonString + "</pre>" );    
    }
}