package com.stuart.api.testing.scenario;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.jayway.restassured.response.Response;
import com.stuart.api.testing.actions.API;
import com.stuart.api.testing.actions.TestGenerator;
import com.stuart.api.testing.data.ErrorMessage;
import com.stuart.api.testing.tools.ReportPrinter;
import java.util.regex.Pattern;
import org.testng.SkipException;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

/**
 * Tests executor
 * @author Jesus Pereira
 */
public class Executor{

    // Soft Assertion to validate and acumulate the errors without fail the test at that moment
    protected SoftAssert softAssert = new SoftAssert();
    
    // Pretty Report Printer
    protected ReportPrinter report = new ReportPrinter();
    
    /**
     * Check Category level
     * @param Category
    **/
    @BeforeTest
    @Parameters({"category"})
    protected void checkCategory(@Optional String category) {
        
        if( !System.getProperty("category").isEmpty() ){
            if ( !( System.getProperty("category").toLowerCase().equalsIgnoreCase("all") ) ) {
                if( category != null ){
                    if( !( System.getProperty("category").toLowerCase().equalsIgnoreCase( category ) ) ){
                        throw new SkipException("Test skipped by its category.");
                    }
                }else{
                    throw new SkipException("Test skipped by its category.");
                }
            }
        }
    }
    
    /**
     * Test
     * @param action
     * @param respCode
     * @param respMsg
     * @param params
     */
    @Test
    @Parameters({"action", "respCode", "respMsg", "params"}) 
    public void validateEndPoint(String action, int respCode, @Optional String respMsg, @Optional String params){
        try {
            long startTime = System.currentTimeMillis();
            TestGenerator test = new TestGenerator(action);
            test.generateBody(params);
            test.generateEndPoint(params);
            long endTime = System.currentTimeMillis();
            long generationTime = (endTime - startTime);
            API apiAction = new API( test.getEndpoint() );
            Response resp = apiAction.sendRequest( test.getMethod(), test.getBody() );
            startTime = System.currentTimeMillis();
            validateResponse( respCode, respMsg, resp.getStatusCode(), resp.getBody().asString() );
            endTime = System.currentTimeMillis();
            long validationTime = (endTime - startTime);
            report.printExecutionTimes( generationTime, resp.getTime(), validationTime );
            softAssert.assertAll();
        } catch (Exception ex) {
            ex.printStackTrace();
            softAssert.assertFalse(true, "Exception: " + ex.getClass() );
            softAssert.assertAll();
        }
    }
    
    /**
     * Response Validator
     **/
    protected void validateResponse(int expectedCode, String expectedMsg, int respCode, String respMsg) {
        report.printSegment("VALIDATIONS:");
        boolean boolCodes = expectedCode == respCode;
        report.printCodesComparison(  expectedCode, respCode, boolCodes);
        softAssert.assertTrue( boolCodes, "THE RESPONSE CODE DOESN'T MATCH!" );
        
        if(expectedMsg != null && (!expectedMsg.equals("")) ){
            boolean boolMsg = false;
            String[] aux = expectedMsg.split("=");
            String type = "";
            String message = "";
            if(aux.length > 1){
                type = aux[0];
                message = aux[1];
                if( type.equalsIgnoreCase("JSONError") ){
                    ErrorMessage errorResp = new ErrorMessage().fromJSONString( respMsg );
                    ErrorMessage errorExpd = new ErrorMessage().fromJSONString( message );
                    boolMsg = errorResp.getError().equalsIgnoreCase( errorExpd.getError() ) 
                           && errorResp.getMessage().equalsIgnoreCase( errorExpd.getMessage() ) ;
                }else
                if( type.equalsIgnoreCase("String") ){
                    boolMsg = respMsg.contains( message );
                }
            }
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            JsonParser jp = new JsonParser();
            Pattern pattern = Pattern.compile("\\{.*\\:.*\\}");
            if( pattern.matcher( message ).matches() ){
                JsonElement je = jp.parse( message );
                message = gson.toJson(je);
            }
            report.printMessageComparion( message,  respMsg , boolMsg );
            softAssert.assertTrue( boolMsg,   "THE RESPONSE DOESN'T CONTAINS: " + expectedMsg );
        }
    }
}
