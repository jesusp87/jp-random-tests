package com.stuart.api.testing.actions;

import static com.jayway.restassured.RestAssured.given;
import com.jayway.restassured.response.Header;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.http.ContentType;
import com.stuart.api.testing.data.MethodEnum;
import com.stuart.api.testing.tools.ReportPrinter;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.testng.Reporter;
import org.testng.TestNGException;

/**
 * Class to simulate endpoint actions
 * @author Jesus Pereira
 **/
public class API{
    
    // Configuration file
    protected Properties configProperties = new Properties();
    
    // Pretty Report Printer
    protected ReportPrinter report = new ReportPrinter();
    
    // Header with authentication
    Header auth;
    
    // Default ContentType
    ContentType contentType = ContentType.JSON;
    
    // Endpoint URL
    String baseURL;
    String endpoint;
    
    /**
     * Constructor API Action
     * @param api
     */
    public API(String path) {
        try {
            // Initialize config properties
            this.configProperties.loadFromXML(new FileInputStream("conf/config-properties.xml"));
        } catch (IOException ex) {
            Logger.getLogger(API.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        // Set endpoint URL
        this.baseURL = configProperties.getProperty("default.baseURL");
        this.endpoint = this.baseURL + path;
        
        // Set authentication
        String tokenType = configProperties.getProperty("default.token_type"); 
        String accessToken = configProperties.getProperty("default.access_token");
        this.auth = new Header( "authorization", tokenType + " " + accessToken );
    }
    
    /**
     * Send Request to a specific endpoint
     * @param method
     * @param body
     * @return  response
     */
    public Response sendRequest(String method, String body) {
        report.printHeadersInformation(method, this.auth.getValue(), this.endpoint);
        Response resp = null;
        try{
            if (MethodEnum.POST.equalsTo( method.toLowerCase() )) {
                resp =  given()
                            .header( this.auth )
                            .contentType(this.contentType)
                            .body(body)
                        .when()
                            .post(this.endpoint)
                        .then()
                        .extract().response();
            }else
            if (MethodEnum.GET.equalsTo( method.toLowerCase() )) {
                resp =  given()
                            .header( this.auth )
                            .contentType("application/x-www-form-urlencoded")
                            .body(body)
                        .when()
                            .get(this.endpoint)
                        .then()
                        .extract().response();
            }
            report.printInformation(body, resp);
            return resp;
        } catch (Exception e){
            throw new TestNGException( "\nException in class: " + this.getClass().getSimpleName() + " (" + this.getClass().getName() + ")\n " + 
                                       "Message: " + e.getMessage() );
        }
    }
    
    /**
     * Modify the authorization parameter
     * @param newAuth
     */
    public void modifyAuthorization (String newAuth) {
        this.auth = new Header("Authorization", newAuth); 
        Reporter.log("<b>Authorization changed to:</b> " + newAuth +"</br>");
    }
}