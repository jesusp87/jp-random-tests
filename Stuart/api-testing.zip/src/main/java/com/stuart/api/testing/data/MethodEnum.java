package com.stuart.api.testing.data;

/**
 * APIs methods
 * @author Jesus Pereira
 **/
public enum MethodEnum {
    GET ("get"), 
    HEAD ("head"),
    POST ("post"),
    PUT ("put"),
    DELETE ("delete"),
    OPTIONS ("options");
    
    private final String method;       

    private MethodEnum(String s) {
        method = s;
    }

    public boolean equalsTo(String otherMethod) {
        return method.equals(otherMethod);
    }

    public String toString() {
       return this.method;
    }
    
    public static MethodEnum byValue(String val){
        for(MethodEnum en:values()){
            if(en.method.equals(val)){
                return en;
            }
        }
    return null;
    }
}